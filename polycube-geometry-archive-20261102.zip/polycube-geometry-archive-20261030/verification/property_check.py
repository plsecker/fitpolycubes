#!/usr/bin/env python3
"""Deterministic property checks for the archived polycube geometry snapshot."""
from __future__ import annotations

import random
import sys
from pathlib import Path

SOURCE = Path(__file__).resolve().parents[1] / "source"
sys.path.insert(0, str(SOURCE))

from polycube_utils import (  # noqa: E402
    face_adjacency_count,
    surface_area,
    voxel_degrees,
    exposed_faces_by_axis,
    bounding_box_dimensions,
    bounding_box_volume,
    occupancy_ratio,
)


def main() -> None:
    rng = random.Random(20261030)
    for case in range(1, 501):
        count = rng.randint(1, 40)
        points = set()
        while len(points) < count:
            points.add((rng.randint(-8, 8), rng.randint(-8, 8), rng.randint(-8, 8)))
        shape = list(points)

        n = len(points)
        edges = face_adjacency_count(shape)
        area = surface_area(shape)
        degrees = voxel_degrees(shape)
        axes = exposed_faces_by_axis(shape)
        dims = bounding_box_dimensions(shape)
        volume = bounding_box_volume(shape)
        ratio = occupancy_ratio(shape)

        assert area == 6 * n - 2 * edges, f"surface identity failed at case {case}"
        assert sum(degrees.values()) == 2 * edges, f"degree identity failed at case {case}"
        assert area == sum(axes.values()), f"axis identity failed at case {case}"
        assert volume == dims[0] * dims[1] * dims[2], f"volume identity failed at case {case}"
        assert abs(ratio - n / volume) < 1e-15, f"occupancy identity failed at case {case}"

        rng.shuffle(shape)
        assert face_adjacency_count(shape) == edges, f"permutation adjacency failed at case {case}"
        assert surface_area(shape) == area, f"permutation area failed at case {case}"
        assert voxel_degrees(shape) == degrees, f"permutation degrees failed at case {case}"

    print("PASS: 500 deterministic random shapes")
    print("PASS: all five mathematical invariants")
    print("PASS: input-order invariance for adjacency, area and voxel degrees")


if __name__ == "__main__":
    main()
