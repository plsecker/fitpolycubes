# Polycube Geometry Archive — 30 October 2026

## Purpose

This archive preserves the uploaded polycube geometry source snapshot, the independent audit findings, a record of the local Spark/OpenCode experiments, and a reproducible verification script.

## Contents

- `source/` — the ten Python files from `polycube-geometry-audit-20261030.zip`, preserved byte-for-byte.
- `GEOMETRY_AUDIT.md` — source-based audit of the geometry utilities and tests.
- `SPARK_OPENCODE_EXPERIMENTS.md` — what the Spark-X2.6-4B experiments demonstrated and what remains unreliable.
- `verification/property_check.py` — deterministic 500-shape invariant and input-order checks.
- `verification/TEST_RESULTS.txt` — recorded independent test results and commands.
- `MANIFEST.sha256` — SHA-256 checksums for every archived file except the manifest itself.

## Reproduce

Use Python 3.11 or newer. From this directory:

```powershell
python -m unittest discover -s source -v
python verification/property_check.py
```

Or from a shell, with the archive root as the current directory:

```bash
python -m unittest discover -s source -v
python verification/property_check.py
```

The uploaded suite contains 81 tests. The independent invariant checker generates 500 deterministic random voxel sets and checks the five geometry identities plus order invariance for selected metrics.

## Baseline and safety

This is an archive of the supplied snapshot. It does not modify or replace the user's permanent `polycube-spark4b-81test-verified-20261030` directory. No implementation changes are included. The connected-components experiment is not part of this source baseline and is not represented as implemented.

## Verification environment

The archive was independently tested in the package-building environment using Python 3.13.5. The user also previously reported a successful 81-test run on TW2. Keep these environments distinct when comparing timings.
