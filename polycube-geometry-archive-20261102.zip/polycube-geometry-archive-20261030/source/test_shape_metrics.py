import itertools
import unittest

from pentacube_orientations import rotation_matrices, rotate_and_normalize
from polycube_utils import (
    bounding_box_dimensions,
    bounding_box_volume,
    occupancy_ratio,
)

DOMINO = ((0,0,0), (1,0,0))
STRAIGHT_5 = tuple((x,0,0) for x in range(5))
SQUARE = ((0,0,0), (1,0,0), (0,1,0), (1,1,0))
CUBE = tuple(itertools.product(range(2), repeat=3))
L_TRIMINO = ((0,0,0), (1,0,0), (1,1,0))
DISCONNECTED = ((0,0,0), (2,0,0))


class ShapeMetricsTests(unittest.TestCase):

    def test_single_voxel(self):
        shape = ((0,0,0),)
        self.assertEqual(bounding_box_volume(shape), 1)
        self.assertEqual(occupancy_ratio(shape), 1.0)

    def test_domino(self):
        self.assertEqual(bounding_box_volume(DOMINO), 2)
        self.assertEqual(occupancy_ratio(DOMINO), 1.0)

    def test_straight_pentacube(self):
        self.assertEqual(bounding_box_volume(STRAIGHT_5), 5)
        self.assertEqual(occupancy_ratio(STRAIGHT_5), 1.0)

    def test_flat_square(self):
        self.assertEqual(bounding_box_volume(SQUARE), 4)
        self.assertEqual(occupancy_ratio(SQUARE), 1.0)

    def test_solid_cube(self):
        self.assertEqual(bounding_box_volume(CUBE), 8)
        self.assertEqual(occupancy_ratio(CUBE), 1.0)

    def test_l_triomino(self):
        self.assertEqual(bounding_box_dimensions(L_TRIMINO), (2,2,1))
        self.assertEqual(bounding_box_volume(L_TRIMINO), 4)
        self.assertAlmostEqual(occupancy_ratio(L_TRIMINO), 0.75)

    def test_disconnected_shape(self):
        self.assertEqual(bounding_box_dimensions(DISCONNECTED), (3,1,1))
        self.assertEqual(bounding_box_volume(DISCONNECTED), 3)
        self.assertAlmostEqual(occupancy_ratio(DISCONNECTED), 2/3)

    def test_translation_invariance(self):
        moved = tuple((x+5,y-3,z+8) for x,y,z in L_TRIMINO)
        self.assertEqual(bounding_box_volume(moved), bounding_box_volume(L_TRIMINO))
        self.assertEqual(occupancy_ratio(moved), occupancy_ratio(L_TRIMINO))

    def test_rotation_invariance(self):
        shapes = (STRAIGHT_5, SQUARE, L_TRIMINO, CUBE)
        for shape in shapes:
            expected_volume = bounding_box_volume(shape)
            expected_ratio = occupancy_ratio(shape)
            for matrix in rotation_matrices():
                rotated = rotate_and_normalize(shape, matrix)
                with self.subTest(shape=shape, matrix=matrix):
                    self.assertEqual(bounding_box_volume(rotated), expected_volume)
                    self.assertAlmostEqual(occupancy_ratio(rotated), expected_ratio)

    def test_invalid_shapes_are_rejected(self):
        for shape in ((), ((0,0,0), (0,0,0))):
            for function in (bounding_box_volume, occupancy_ratio):
                with self.subTest(shape=shape, function=function.__name__):
                    with self.assertRaises(ValueError):
                        function(shape)


if __name__ == '__main__':
    unittest.main(verbosity=2)