import itertools
import unittest

from polycube_utils import (
    face_adjacency_count,
    normalize_shape,
    surface_area,
)


class FaceAdjacencyCountTests(unittest.TestCase):

    def test_single_voxel(self):
        self.assertEqual(face_adjacency_count(((0, 0, 0),)), 0)

    def test_domino(self):
        self.assertEqual(face_adjacency_count(((0, 0, 0), (1, 0, 0))), 1)

    def test_straight_pentacube(self):
        shape = tuple((x, 0, 0) for x in range(5))
        self.assertEqual(face_adjacency_count(shape), 4)

    def test_flat_square(self):
        shape = ((0,0,0), (1,0,0), (0,1,0), (1,1,0))
        self.assertEqual(face_adjacency_count(shape), 4)

    def test_solid_cube(self):
        shape = tuple(itertools.product(range(2), repeat=3))
        self.assertEqual(face_adjacency_count(shape), 12)

    def test_l_triomino(self):
        shape = ((0,0,0), (1,0,0), (1,1,0))
        self.assertEqual(face_adjacency_count(shape), 2)

    def test_disconnected_voxels(self):
        shape = ((0,0,0), (2,0,0))
        self.assertEqual(face_adjacency_count(shape), 0)

    def test_translation_invariance(self):
        shape = ((0,0,0), (1,0,0), (1,1,0))
        moved = tuple((x+5, y-3, z+8) for x,y,z in shape)
        self.assertEqual(face_adjacency_count(shape), face_adjacency_count(moved))

    def test_surface_area_identity(self):
        shapes = [
            ((0,0,0),),
            ((0,0,0), (1,0,0)),
            tuple((x,0,0) for x in range(5)),
            ((0,0,0), (1,0,0), (0,1,0), (1,1,0)),
            tuple(itertools.product(range(2), repeat=3)),
            ((0,0,0), (1,0,0), (1,1,0)),
            ((0,0,0), (2,0,0)),
        ]
        for shape in shapes:
            with self.subTest(shape=shape):
                count = len(normalize_shape(shape))
                self.assertEqual(
                    surface_area(shape),
                    6 * count - 2 * face_adjacency_count(shape),
                )

    def test_invalid_inputs_are_rejected(self):
        for shape in ((), ((0,0,0), (0,0,0))):
            with self.subTest(shape=shape):
                with self.assertRaises(ValueError):
                    face_adjacency_count(shape)


if __name__ == '__main__':
    unittest.main(verbosity=2)