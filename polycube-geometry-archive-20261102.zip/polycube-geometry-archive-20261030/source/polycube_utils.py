"""Utilities for working with polycube shapes (sets of voxels).

Only the Python standard library is used, plus the helper module
``pentacube_orientations`` (``rotation_matrices`` and ``rotate_and_normalize``).
"""

from typing import Iterable, List, Tuple

from pentacube_orientations import rotation_matrices, rotate_and_normalize

Coord = Tuple[int, int, int]
Point = Tuple[Coord, ...]


def normalize_shape(shape):
    """Validate, normalize and sort a shape of 3D integer coordinates."""
    try:
        raw_voxels = list(shape)
    except (TypeError, ValueError) as exc:
        raise ValueError("shape must be an iterable of coordinates") from exc

    if not raw_voxels:
        raise ValueError("shape must contain at least one voxel")

    voxels = []

    for voxel in raw_voxels:
        try:
            coordinates = tuple(voxel)
        except (TypeError, ValueError) as exc:
            raise ValueError("each voxel must contain three coordinates") from exc

        if len(coordinates) != 3:
            raise ValueError("each voxel must contain exactly three coordinates")

        converted = []

        for value in coordinates:
            if isinstance(value, bool):
                raise ValueError("boolean coordinates are not allowed")

            if isinstance(value, int):
                converted.append(value)
            elif isinstance(value, float) and value.is_integer():
                converted.append(int(value))
            else:
                raise ValueError("coordinates must be integer values")

        voxels.append(tuple(converted))

    if len(set(voxels)) != len(voxels):
        raise ValueError("duplicate voxels are not allowed")

    min_x = min(point[0] for point in voxels)
    min_y = min(point[1] for point in voxels)
    min_z = min(point[2] for point in voxels)

    normalized = (
        (x - min_x, y - min_y, z - min_z)
        for x, y, z in voxels
    )

    return tuple(sorted(normalized))

def bounding_box_dimensions(shape):
    """Return the integer width, height and depth of the bounding box of a shape.

    ``normalize_shape`` validates and normalizes the input first, so coordinates
    are integers and already shifted to the origin. The bounding box dimensions
    are computed from the maximum coordinate on each axis; each dimension is the
    max coordinate plus one. No connectivity assumption is made.
    """
    normalized = normalize_shape(shape)
    widths = [coord[0] for coord in normalized]
    heights = [coord[1] for coord in normalized]
    depths = [coord[2] for coord in normalized]
    width = max(widths) + 1
    height = max(heights) + 1
    depth = max(depths) + 1
    return (width, height, depth)

def is_face_connected(shape: Iterable[Coord]) -> bool:
    """Return True if every voxel of the shape is face-connected to every other.

    Adds the input through :func:`normalize_shape` so its validation rules
    apply, then treats each coordinate triple as one voxel and performs a
    breadth-first search across the face-adjacency relation (Manhattan distance
    exactly 1). Returns True when all voxels are reachable.
    """
    normalized = normalize_shape(shape)
    voxels = list(normalized)
    if not voxels:
        raise ValueError("shape must contain at least one voxel")

    # Space of possible adjacent coordinates around a voxel.
    neighbors = [(1, 0, 0), (-1, 0, 0), (0, 1, 0), (0, -1, 0),
                 (0, 0, 1), (0, 0, -1)]

    visited = set()
    queue = [voxels[0]]
    visited.add(voxels[0])

    while queue:
        coord = queue.pop(0)
        for offset in neighbors:
            ncoord = (coord[0] + offset[0], coord[1] + offset[1], coord[2] + offset[2])
            if ncoord in voxels and ncoord not in visited:
                visited.add(ncoord)
                queue.append(ncoord)

    return len(visited) == len(voxels)



def canonical_shape(shape):
    """Return the lexicographically smallest orientation under proper rotations."""
    from pentacube_orientations import rotation_matrices, rotate_and_normalize

    normalized = normalize_shape(shape)
    return min(
        rotate_and_normalize(normalized, matrix)
        for matrix in rotation_matrices()
    )


def orientation_count(shape):
    """Return the number of distinct orientations under proper rotations."""
    from pentacube_orientations import rotation_matrices, rotate_and_normalize

    normalized = normalize_shape(shape)
    orientations = {
        rotate_and_normalize(normalized, matrix)
        for matrix in rotation_matrices()
    }
    return len(orientations)

def surface_area(shape):
    """Return the total exposed unit-face count for a voxel shape."""
    return sum(exposed_faces_by_axis(shape).values())

def face_adjacency_count(shape):
    """Return the number of unordered pairs of voxels that share a face.

    The shape is validated and normalized through :func:`normalize_shape`,
    then used as a set of coordinates. Only the +x, +y, and +z neighbours
    are checked for each voxel, so each shared face is counted once.
    """
    normalized = normalize_shape(shape)
    occupied = set(normalized)
    count = 0
    for x, y, z in occupied:
        if (x + 1, y, z) in occupied:
            count += 1
        if (x, y + 1, z) in occupied:
            count += 1
        if (x, y, z + 1) in occupied:
            count += 1
    return count

def voxel_degrees(shape):
    """Return the face-degree (neighbour count) of every voxel in a shape.

    The shape is validated and normalized through :func:`normalize_shape`, then
    used as a set of normalized coordinates. For each voxel the six axis
    neighbours (``+-1`` in ``x``, ``y`` and ``z``) are checked; a neighbour is
    counted when it is also occupied. Isolated voxels (no occupying neighbours)
    are included with a degree of zero.
    """
    normalized = normalize_shape(shape)
    occupied = set(normalized)
    degrees = {coord: 0 for coord in normalized}

    for x, y, z in normalized:
        if (x - 1, y, z) in occupied:
            degrees[(x, y, z)] += 1
        if (x + 1, y, z) in occupied:
            degrees[(x, y, z)] += 1

        if (x, y - 1, z) in occupied:
            degrees[(x, y, z)] += 1
        if (x, y + 1, z) in occupied:
            degrees[(x, y, z)] += 1

        if (x, y, z - 1) in occupied:
            degrees[(x, y, z)] += 1
        if (x, y, z + 1) in occupied:
            degrees[(x, y, z)] += 1

    return degrees


def exposed_faces_by_axis(shape):
    """Count exposed unit faces by axis, combining both directions per axis."""
    voxels = normalize_shape(shape)
    occupied = set(voxels)

    counts = {"x": 0, "y": 0, "z": 0}

    for x, y, z in voxels:
        if (x - 1, y, z) not in occupied:
            counts["x"] += 1
        if (x + 1, y, z) not in occupied:
            counts["x"] += 1

        if (x, y - 1, z) not in occupied:
            counts["y"] += 1
        if (x, y + 1, z) not in occupied:
            counts["y"] += 1

        if (x, y, z - 1) not in occupied:
            counts["z"] += 1
        if (x, y, z + 1) not in occupied:
            counts["z"] += 1

    return counts

def bounding_box_volume(shape):
    """Return the volume of the smallest axis-aligned box enclosing shape."""
    width, height, depth = bounding_box_dimensions(shape)
    return width * height * depth

def occupancy_ratio(shape):
    """Return the fraction of the bounding box occupied by voxels."""
    normalized = normalize_shape(shape)
    volume = bounding_box_volume(normalized)
    return len(normalized) / volume
