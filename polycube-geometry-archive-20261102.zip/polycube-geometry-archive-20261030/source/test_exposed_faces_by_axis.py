import itertools
import unittest

from pentacube_orientations import rotation_matrices, rotate_and_normalize
from polycube_utils import exposed_faces_by_axis, surface_area

DOMINO = ((0, 0, 0), (1, 0, 0))
STRAIGHT_5 = tuple((x, 0, 0) for x in range(5))
SQUARE = ((0,0,0), (1,0,0), (0,1,0), (1,1,0))
CUBE = tuple(itertools.product(range(2), repeat=3))
L_TRIMINO = ((0,0,0), (1,0,0), (1,1,0))
DISCONNECTED = ((0,0,0), (2,0,0))


class ExposedFacesByAxisTests(unittest.TestCase):

    def test_single_voxel(self):
        self.assertEqual(
            exposed_faces_by_axis(((0,0,0),)),
            {"x": 2, "y": 2, "z": 2},
        )

    def test_domino(self):
        self.assertEqual(
            exposed_faces_by_axis(DOMINO),
            {"x": 2, "y": 4, "z": 4},
        )

    def test_straight_pentacube(self):
        self.assertEqual(
            exposed_faces_by_axis(STRAIGHT_5),
            {"x": 2, "y": 10, "z": 10},
        )

    def test_flat_square(self):
        self.assertEqual(
            exposed_faces_by_axis(SQUARE),
            {"x": 4, "y": 4, "z": 8},
        )

    def test_solid_cube(self):
        self.assertEqual(
            exposed_faces_by_axis(CUBE),
            {"x": 8, "y": 8, "z": 8},
        )

    def test_l_triomino(self):
        self.assertEqual(
            exposed_faces_by_axis(L_TRIMINO),
            {"x": 4, "y": 4, "z": 6},
        )

    def test_disconnected_voxels(self):
        self.assertEqual(
            exposed_faces_by_axis(DISCONNECTED),
            {"x": 4, "y": 4, "z": 4},
        )

    def test_translation_invariance(self):
        moved = tuple((x+5, y-3, z+8) for x,y,z in L_TRIMINO)
        self.assertEqual(
            exposed_faces_by_axis(moved),
            exposed_faces_by_axis(L_TRIMINO),
        )

    def test_axis_counts_sum_to_surface_area(self):
        shapes = [
            ((0,0,0),), DOMINO, STRAIGHT_5, SQUARE,
            CUBE, L_TRIMINO, DISCONNECTED,
        ]
        for shape in shapes:
            with self.subTest(shape=shape):
                counts = exposed_faces_by_axis(shape)
                self.assertEqual(set(counts), {"x", "y", "z"})
                self.assertTrue(all(type(v) is int and v >= 0
                                    for v in counts.values()))
                self.assertEqual(sum(counts.values()), surface_area(shape))

    def test_rotation_preserves_total_surface_area(self):
        original_area = surface_area(L_TRIMINO)
        for matrix in rotation_matrices():
            rotated = rotate_and_normalize(L_TRIMINO, matrix)
            self.assertEqual(surface_area(rotated), original_area)
            self.assertEqual(
                sum(exposed_faces_by_axis(rotated).values()), original_area
            )

    def test_invalid_inputs_are_rejected(self):
        for shape in ((), ((0,0,0), (0,0,0))):
            with self.subTest(shape=shape):
                with self.assertRaises(ValueError):
                    exposed_faces_by_axis(shape)


if __name__ == "__main__":
    unittest.main(verbosity=2)