import itertools
import unittest

from polycube_utils import surface_area


class SurfaceAreaTests(unittest.TestCase):

    def test_single_voxel(self):
        self.assertEqual(surface_area(((0, 0, 0),)), 6)

    def test_domino(self):
        self.assertEqual(surface_area(((0, 0, 0), (1, 0, 0))), 10)

    def test_straight_pentacube(self):
        self.assertEqual(surface_area(tuple((x, 0, 0) for x in range(5))), 22)

    def test_flat_square(self):
        shape = ((0,0,0), (1,0,0), (0,1,0), (1,1,0))
        self.assertEqual(surface_area(shape), 16)

    def test_solid_cube(self):
        shape = tuple(itertools.product(range(2), repeat=3))
        self.assertEqual(surface_area(shape), 24)

    def test_l_triomino(self):
        self.assertEqual(
            surface_area(((0,0,0), (1,0,0), (1,1,0))), 14
        )

    def test_disconnected_voxels(self):
        self.assertEqual(surface_area(((0,0,0), (2,0,0))), 12)

    def test_translation_invariance(self):
        shape = ((0,0,0), (1,0,0), (1,1,0))
        moved = tuple((x+5, y-3, z+8) for x,y,z in shape)
        self.assertEqual(surface_area(shape), surface_area(moved))

    def test_rejects_empty_shape(self):
        with self.assertRaises(ValueError):
            surface_area(())

    def test_rejects_duplicate_voxels(self):
        with self.assertRaises(ValueError):
            surface_area(((0,0,0), (0,0,0)))


if __name__ == '__main__':
    unittest.main(verbosity=2)