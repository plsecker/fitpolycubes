import itertools
import unittest

from pentacube_orientations import (
    determinant,
    rotation_matrices,
    rotate_and_normalize,
    distinct_orientations,
)

STRAIGHT = (
    (0, 0, 0),
    (1, 0, 0),
    (2, 0, 0),
    (3, 0, 0),
    (4, 0, 0),
)


def manhattan(a, b):
    return sum(abs(x - y) for x, y in zip(a, b))


def distance_multiset(shape):
    return sorted(
        manhattan(a, b)
        for a, b in itertools.combinations(shape, 2)
    )


def is_face_connected(shape):
    remaining = set(shape)
    if not remaining:
        return False

    reached = {next(iter(remaining))}
    while True:
        new = {
            point
            for point in remaining - reached
            if any(manhattan(point, visited) == 1 for visited in reached)
        }
        if not new:
            break
        reached.update(new)

    return reached == remaining


class PentacubeRotationTests(unittest.TestCase):

    def test_determinant_known_matrices(self):
        self.assertEqual(
            determinant([[1, 0, 0], [0, 1, 0], [0, 0, 1]]), 1
        )
        self.assertEqual(
            determinant([[0, 1, 0], [1, 0, 0], [0, 0, 1]]), -1
        )
        self.assertEqual(
            determinant([[1, 2, 3], [2, 4, 6], [0, 0, 0]]), 0
        )

    def test_exactly_24_unique_proper_rotations(self):
        matrices = rotation_matrices()
        canonical = {
            tuple(tuple(value for value in row) for row in matrix)
            for matrix in matrices
        }
        self.assertEqual(len(matrices), 24)
        self.assertEqual(len(canonical), 24)

    def test_every_rotation_is_a_proper_signed_permutation(self):
        for matrix in rotation_matrices():
            self.assertEqual(determinant(matrix), 1)
            for row in matrix:
                self.assertEqual(sum(value != 0 for value in row), 1)
                self.assertTrue(all(value in (-1, 0, 1) for value in row))
            for column in range(3):
                self.assertEqual(
                    sum(matrix[row][column] != 0 for row in range(3)), 1
                )

    def test_exactly_three_straight_pentacube_orientations(self):
        self.assertEqual(len(distinct_orientations(STRAIGHT)), 3)

    def test_each_orientation_has_five_unique_voxels(self):
        for orientation in distinct_orientations(STRAIGHT):
            self.assertEqual(len(orientation), 5)
            self.assertEqual(len(set(orientation)), 5)

    def test_orientations_are_normalized_on_every_axis(self):
        for orientation in distinct_orientations(STRAIGHT):
            for axis in range(3):
                self.assertEqual(min(p[axis] for p in orientation), 0)

    def test_every_orientation_is_face_connected(self):
        for orientation in distinct_orientations(STRAIGHT):
            self.assertTrue(is_face_connected(orientation), orientation)

    def test_pairwise_manhattan_distances_are_preserved(self):
        original_distances = distance_multiset(STRAIGHT)
        for matrix in rotation_matrices():
            rotated = rotate_and_normalize(STRAIGHT, matrix)
            self.assertEqual(distance_multiset(rotated), original_distances)

    def test_results_are_deterministic_and_sorted(self):
        first = distinct_orientations(STRAIGHT)
        second = distinct_orientations(STRAIGHT)
        self.assertEqual(first, second)
        self.assertEqual(first, sorted(first))

    def test_rotated_coordinates_are_sorted_and_immutable(self):
        for matrix in rotation_matrices():
            orientation = rotate_and_normalize(STRAIGHT, matrix)
            self.assertIsInstance(orientation, tuple)
            self.assertEqual(orientation, tuple(sorted(orientation)))
            self.assertTrue(all(isinstance(point, tuple) for point in orientation))


if __name__ == '__main__':
    unittest.main(verbosity=2)