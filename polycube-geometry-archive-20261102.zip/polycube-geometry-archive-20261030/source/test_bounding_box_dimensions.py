import unittest

from pentacube_orientations import rotation_matrices, rotate_and_normalize
from polycube_utils import bounding_box_dimensions

DOMINO = ((0,0,0), (1,0,0))
STRAIGHT_5 = tuple((x,0,0) for x in range(5))
SQUARE = ((0,0,0), (1,0,0), (0,1,0), (1,1,0))
CUBE = tuple(
    (x,y,z)
    for x in range(2)
    for y in range(2)
    for z in range(2)
)
L_TRIMINO = ((0,0,0), (1,0,0), (1,1,0))
DISCONNECTED = ((0,0,0), (2,0,0))


class BoundingBoxDimensionsTests(unittest.TestCase):

    def test_single_voxel(self):
        self.assertEqual(bounding_box_dimensions(((0,0,0),)), (1,1,1))

    def test_domino(self):
        self.assertEqual(bounding_box_dimensions(DOMINO), (2,1,1))

    def test_straight_pentacube(self):
        self.assertEqual(bounding_box_dimensions(STRAIGHT_5), (5,1,1))

    def test_flat_square(self):
        self.assertEqual(bounding_box_dimensions(SQUARE), (2,2,1))

    def test_solid_cube(self):
        self.assertEqual(bounding_box_dimensions(CUBE), (2,2,2))

    def test_l_triomino(self):
        self.assertEqual(bounding_box_dimensions(L_TRIMINO), (2,2,1))

    def test_disconnected_shape(self):
        self.assertEqual(bounding_box_dimensions(DISCONNECTED), (3,1,1))

    def test_translation_invariance(self):
        moved = tuple((x+5,y-3,z+8) for x,y,z in L_TRIMINO)
        self.assertEqual(
            bounding_box_dimensions(moved),
            bounding_box_dimensions(L_TRIMINO),
        )

    def test_rotation_permutates_dimensions(self):
        for shape in (STRAIGHT_5, SQUARE, L_TRIMINO, CUBE):
            expected = sorted(bounding_box_dimensions(shape))
            for matrix in rotation_matrices():
                rotated = rotate_and_normalize(shape, matrix)
                with self.subTest(shape=shape, matrix=matrix):
                    self.assertEqual(
                        sorted(bounding_box_dimensions(rotated)),
                        expected,
                    )

    def test_invalid_inputs_are_rejected(self):
        for shape in ((), ((0,0,0), (0,0,0))):
            with self.subTest(shape=shape):
                with self.assertRaises(ValueError):
                    bounding_box_dimensions(shape)


if __name__ == '__main__':
    unittest.main(verbosity=2)