"""Count orientations of a straight pentacube using a standard-library-only M-of solution.

The straight pentacube consists of 5 unit cubes placed in a single row:
((0,0,0), (1,0,0), (2,0,0), (3,0,0), (4,0,0)).

This implementation:
- constructs exactly 24 rotation matrices (signed permutation matrices with determinant +1);
- rotates the shape with each matrix and normalizes (checks the lowest nonzero extent on each axis);
- collects distinct normalized orientations;
- prints the rotation count and the orientation count.
"""


def determinant(matrix):
    """Return the determinant of a 3x3 matrix (standard-library only)."""
    a, b, c = matrix[0][0], matrix[0][1], matrix[0][2]
    d, e, f = matrix[1][0], matrix[1][1], matrix[1][2]
    g, h, i = matrix[2][0], matrix[2][1], matrix[2][2]
    return a * (e * i - f * h) - b * (d * i - f * g) + c * (d * h - e * g)


def rotation_matrices():
    """Return exactly 24 distinct signed permutation matrices with determinant +1.

    Every row and every column contains exactly one nonzero entry (which is +1 or -1),
    and the determinant must be +1.  The matrices are generated systematically from
    the 48 signed permutation matrices (permutations of coordinates combined with
    independent sign choices), filtering those with determinant +1.
    """
    matrices = []
    import itertools
    for perm in itertools.permutations(range(3)):
        for signs in itertools.product((1, -1), repeat=3):
            matrix = [[0, 0, 0],
                      [0, 0, 0],
                      [0, 0, 0]]
            # Place sign[i] at position (perm[i], i)
            for idx, position in enumerate(perm):
                matrix[position][idx] = signs[idx]
            if determinant(matrix) == 1:
                matrices.append(matrix)
    # Distinct rotations only; the permutation/sign generation yields each signed
    # permutation matrix exactly once.
    return matrices


def rotate_and_normalize(shape, matrix):
    """Rotate all shape coordinates by the given rotation matrix, then normalize.

    Every coordinate is rotated first. Across all rotated voxels, the minimum x, the
    minimum y, and the minimum z are computed separately (each axis's minimum). Each
    voxel is then shifted by its own axis's minimum (x -= min_x, y -= min_y, z -=
    min_z). The normalized coordinates are sorted deterministically and returned as an
    immutable tuple of coordinate tuples, so the result can be used as a set member.
    """
    rotated = []
    for x, y, z in shape:
        new_x = matrix[0][0] * x + matrix[0][1] * y + matrix[0][2] * z
        new_y = matrix[1][0] * x + matrix[1][1] * y + matrix[1][2] * z
        new_z = matrix[2][0] * x + matrix[2][1] * y + matrix[2][2] * z
        rotated.append((new_x, new_y, new_z))
    min_x = min(voxel[0] for voxel in rotated)
    min_y = min(voxel[1] for voxel in rotated)
    min_z = min(voxel[2] for voxel in rotated)
    normalized = [
        (x - min_x, y - min_y, z - min_z)
        for x, y, z in rotated
    ]
    normalized.sort()
    return tuple(normalized)


def distinct_orientations(shape):
    """Return the sorted, unique set of normalized orientations for the shape."""
    orientations = set()
    for matrix in rotation_matrices():
        orientations.add(rotate_and_normalize(shape, matrix))
    return sorted(orientations)


def main():
    straight_shape = ((0, 0, 0), (1, 0, 0), (2, 0, 0), (3, 0, 0), (4, 0, 0))
    rotation_count = len(rotation_matrices())
    orientation_count = len(distinct_orientations(straight_shape))
    print("rotation matrices:", rotation_count)
    print("distinct orientations:", orientation_count)


if __name__ == "__main__":
    main()
