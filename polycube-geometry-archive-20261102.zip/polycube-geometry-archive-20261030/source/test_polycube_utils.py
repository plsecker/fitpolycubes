import unittest

from pentacube_orientations import rotation_matrices, rotate_and_normalize
from polycube_utils import (
    normalize_shape,
    is_face_connected,
    canonical_shape,
    orientation_count,
)

STRAIGHT_5 = (
    (0, 0, 0), (1, 0, 0), (2, 0, 0), (3, 0, 0), (4, 0, 0)
)
DOMINO = ((0, 0, 0), (1, 0, 0))
L_TRIMINO = ((0, 0, 0), (1, 0, 0), (1, 1, 0))
SQUARE = ((0, 0, 0), (1, 0, 0), (0, 1, 0), (1, 1, 0))


class PolyCubeUtilityTests(unittest.TestCase):

    def test_normalization_and_translation_invariance(self):
        shape = ((5, -2, 9), (6, -2, 9), (6, -1, 9))
        expected = ((0, 0, 0), (1, 0, 0), (1, 1, 0))
        self.assertEqual(normalize_shape(shape), expected)

    def test_normalized_result_is_immutable_and_sorted(self):
        result = normalize_shape(((1, 1, 0), (0, 0, 0), (1, 0, 0)))
        self.assertIsInstance(result, tuple)
        self.assertEqual(result, tuple(sorted(result)))
        self.assertTrue(all(isinstance(point, tuple) for point in result))

    def test_integer_valued_floats_are_accepted(self):
        shape = ((0.0, 0.0, 0.0), (1.0, 0.0, 0.0))
        result = normalize_shape(shape)
        self.assertEqual(result, DOMINO)
        self.assertTrue(all(type(v) is int for p in result for v in p))

    def test_invalid_shapes_raise_value_error(self):
        invalid_shapes = (
            (),
            ((0, 0, 0), (0, 0, 0)),
            ((0, 0), (1, 1)),
            ((0, 0, 0), (1, 0, 0.5)),
            ((False, 0, 0),),
        )
        for shape in invalid_shapes:
            with self.subTest(shape=shape):
                with self.assertRaises(ValueError):
                    normalize_shape(shape)

    def test_face_connectivity(self):
        self.assertTrue(is_face_connected(((0, 0, 0),)))
        self.assertTrue(is_face_connected(L_TRIMINO))
        self.assertFalse(is_face_connected(((0, 0, 0), (2, 0, 0))))

    def test_canonical_shape_is_translation_invariant(self):
        translated = tuple((x + 7, y - 4, z + 2) for x, y, z in L_TRIMINO)
        self.assertEqual(canonical_shape(L_TRIMINO), canonical_shape(translated))

    def test_canonical_shape_is_rotation_invariant(self):
        expected = canonical_shape(L_TRIMINO)
        for matrix in rotation_matrices():
            rotated = rotate_and_normalize(L_TRIMINO, matrix)
            with self.subTest(matrix=matrix):
                self.assertEqual(canonical_shape(rotated), expected)

    def test_canonical_shape_is_normalized_and_integer_valued(self):
        result = canonical_shape(L_TRIMINO)
        self.assertIsInstance(result, tuple)
        for axis in range(3):
            self.assertEqual(min(point[axis] for point in result), 0)
        self.assertTrue(all(type(v) is int for p in result for v in p))

    def test_known_orientation_counts(self):
        self.assertEqual(orientation_count(((0, 0, 0),)), 1)
        self.assertEqual(orientation_count(DOMINO), 3)
        self.assertEqual(orientation_count(STRAIGHT_5), 3)
        self.assertEqual(orientation_count(SQUARE), 3)
        self.assertEqual(orientation_count(L_TRIMINO), 12)

    def test_orientation_count_is_rotation_invariant(self):
        expected = orientation_count(L_TRIMINO)
        for matrix in rotation_matrices():
            rotated = rotate_and_normalize(L_TRIMINO, matrix)
            with self.subTest(matrix=matrix):
                self.assertEqual(orientation_count(rotated), expected)


if __name__ == '__main__':
    unittest.main(verbosity=2)