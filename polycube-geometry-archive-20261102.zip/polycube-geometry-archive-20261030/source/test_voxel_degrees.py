import unittest

from polycube_utils import voxel_degrees, face_adjacency_count

DOMINO = ((0,0,0), (1,0,0))
STRAIGHT_5 = tuple((x,0,0) for x in range(5))
SQUARE = ((0,0,0), (1,0,0), (0,1,0), (1,1,0))
CUBE = tuple(
    (x,y,z)
    for x in range(2)
    for y in range(2)
    for z in range(2)
)
L_TRIMINO = ((0,0,0), (1,0,0), (1,1,0))
DISCONNECTED = ((0,0,0), (2,0,0))


class VoxelDegreeTests(unittest.TestCase):

    def test_single_voxel(self):
        self.assertEqual(voxel_degrees(((0,0,0),)), {(0,0,0): 0})

    def test_domino(self):
        self.assertEqual(voxel_degrees(DOMINO), {
            (0,0,0): 1, (1,0,0): 1
        })

    def test_straight_pentacube(self):
        self.assertEqual(voxel_degrees(STRAIGHT_5), {
            (0,0,0): 1,
            (1,0,0): 2,
            (2,0,0): 2,
            (3,0,0): 2,
            (4,0,0): 1,
        })

    def test_flat_square(self):
        self.assertEqual(set(voxel_degrees(SQUARE).values()), {2})
        self.assertEqual(len(voxel_degrees(SQUARE)), 4)

    def test_solid_cube(self):
        self.assertEqual(set(voxel_degrees(CUBE).values()), {3})
        self.assertEqual(len(voxel_degrees(CUBE)), 8)

    def test_l_triomino(self):
        self.assertEqual(voxel_degrees(L_TRIMINO), {
            (0,0,0): 1, (1,0,0): 2, (1,1,0): 1
        })

    def test_disconnected_voxels(self):
        self.assertEqual(voxel_degrees(DISCONNECTED), {
            (0,0,0): 0, (2,0,0): 0
        })

    def test_translation_invariance(self):
        moved = tuple((x+5,y-3,z+8) for x,y,z in L_TRIMINO)
        self.assertEqual(voxel_degrees(moved), voxel_degrees(L_TRIMINO))

    def test_degree_sum_equals_twice_adjacency_count(self):
        shapes = (
            ((0,0,0),), DOMINO, STRAIGHT_5,
            SQUARE, CUBE, L_TRIMINO, DISCONNECTED,
        )
        for shape in shapes:
            with self.subTest(shape=shape):
                self.assertEqual(
                    sum(voxel_degrees(shape).values()),
                    2 * face_adjacency_count(shape),
                )

    def test_invalid_shapes_are_rejected(self):
        for shape in ((), ((0,0,0), (0,0,0))):
            with self.subTest(shape=shape):
                with self.assertRaises(ValueError):
                    voxel_degrees(shape)


if __name__ == '__main__':
    unittest.main(verbosity=2)