# Independent Geometry Audit

**Snapshot date:** 30 October 2026  
**Scope:** `source/polycube_utils.py` and its seven geometry test modules. The two pentacube-orientation files are retained as supporting source and their ten tests are included in the full suite.

## Executive summary

The supplied geometry package passes its 81-test suite. The implementation's central geometric calculations are mutually consistent. An additional deterministic property check over 500 generated shapes also passed all five invariants and selected input-order invariance checks.

No confirmed correctness defect was found in the reviewed geometry utilities. The clearest improvement is performance-related: `is_face_connected()` uses a list as both its membership structure and FIFO queue, making traversal quadratic in the number of voxels. For pentacube-sized inputs this is unlikely to matter; for larger polycubes, a set plus `collections.deque` would make the traversal approximately linear.

This report distinguishes source inspection, existing tests and additional independent checks. It does not claim proof for all possible inputs or all Python numeric types.

## 1. Function inventory

| Function | Behaviour | Complexity (including normalization) | Assessment |
|---|---|---:|---|
| `normalize_shape` | Materialises an iterable, validates 3D coordinates, rejects duplicates, translates minima to zero, sorts and returns a tuple. | O(N log N) time; O(N) space | Consistent validation core. |
| `bounding_box_dimensions` | Returns max normalized coordinate + 1 on each axis. | O(N log N) | Correct for nonempty normalized shapes. |
| `is_face_connected` | BFS over six axis-neighbours; reports whether all voxels are reachable. | O(N²) worst case | Correct face-adjacency semantics; avoidable quadratic work. |
| `canonical_shape` | Normalizes, rotates under proper rotations, chooses lexicographic minimum. | 24 rotations; approximately O(24 N log N) | Normalization interaction is consistent. Full rotation audit is out of scope. |
| `orientation_count` | Counts distinct normalized proper-rotation images. | 24 rotations; approximately O(24 N log N) | Normalization interaction is consistent. |
| `surface_area` | Sums the three axis-wise exposed-face counts. | O(N log N) | Correct. |
| `face_adjacency_count` | Checks only +X, +Y and +Z neighbours so each shared face is counted once. | O(N log N) | Correct. |
| `voxel_degrees` | Counts six face-neighbours for every normalized voxel, including zero-degree voxels. | O(N log N) | Correct. |
| `exposed_faces_by_axis` | Counts missing neighbours in both directions on each axis. | O(N log N) | Correct. |
| `bounding_box_volume` | Multiplies the three bounding-box dimensions. | O(N log N) | Correct. |
| `occupancy_ratio` | Divides voxel count by bounding-box volume. | O(N log N), with repeated normalization | Correct; one redundant normalization pass. |

N denotes voxel count. Sorting inside `normalize_shape` contributes O(N log N) to many public operations. Set construction and the fixed six-neighbour loops are O(N) average-time after normalization.

## 2. Mathematical invariants

Let N be the number of voxels, E the number of unordered face-adjacent pairs, A the total exposed unit-face count, and d(v) the face-degree of voxel v.

### Surface area

\[
A = 6N - 2E
\]

Each isolated unit cube contributes six faces. Every shared face belongs to two voxels and is internal, so each adjacency removes two exposed faces. `face_adjacency_count()` counts each unordered pair once by examining positive directions only; `surface_area()` sums exposed faces by axis. The relation is also explicitly tested by `test_surface_area_identity`.

### Degree sum

\[
\sum_v d(v) = 2E
\]

Each adjacency contributes one to the degree of each endpoint. `voxel_degrees()` checks all six directions, so each adjacency contributes exactly two to the sum. Existing test: `test_degree_sum_equals_twice_adjacency_count`.

### Axis aggregation

\[
A = A_x + A_y + A_z
\]

Each exposed face has exactly one axis orientation. `exposed_faces_by_axis()` returns keys `x`, `y`, `z`; `test_axis_counts_sum_to_surface_area` checks aggregation over representative shapes.

### Bounding volume and occupancy

\[
V = w h d, \qquad R = N/V
\]

The dimensions are inclusive extents after normalization (maximum coordinate plus one). A nonempty shape has each dimension at least one, so V is positive. `occupancy_ratio()` uses the normalized voxel count divided by this volume. Tests include disconnected shapes and rotational/translation invariance.

All five identities passed the deterministic 500-shape verification in `verification/property_check.py`.

## 3. Input normalization and validation

`normalize_shape()` first materialises `shape`, so lists, tuples and finite generators are supported. It converts each voxel to a tuple and requires exactly three values. Python `bool` is rejected explicitly, despite being a subclass of `int`. Python integers are retained; integer-valued Python floats are converted to integers; fractional floats and other coordinate types are rejected with `ValueError`. Duplicate coordinate triples are rejected before translation. Empty or non-iterable outer shapes and malformed/non-iterable voxel coordinates are rejected. Negative coordinates are supported because the minimum on each axis is subtracted. Python integers support arbitrary precision, subject to practical memory/time limits.

Potential contract boundary: non-builtin integer scalar types (for example, some third-party numeric scalar classes) are not necessarily accepted because the implementation checks `isinstance(value, int)` and `isinstance(value, float)`. This is not a defect unless broader numeric interoperability is intended.

The geometry functions consistently call `normalize_shape()` directly or through another public geometry function. `occupancy_ratio()` normalizes and then passes the result through `bounding_box_volume()`, which normalizes again; this is redundant, not incorrect.

## 4. Geometric fixture calculations

| Fixture | N | E | A = 6N − 2E | Degrees | Bounding box | V | R |
|---|---:|---:|---:|---|---|---:|---:|
| Single voxel | 1 | 0 | 6 | {0} | 1×1×1 | 1 | 1.0 |
| Straight line of 5 | 5 | 4 | 22 | {1,1,2,2,2} | 5×1×1 | 5 | 1.0 |
| Flat 2×2 square | 4 | 4 | 16 | {2,2,2,2} | 2×2×1 | 4 | 1.0 |
| Solid 2×2×2 cube | 8 | 12 | 24 | eight voxels of degree 3 | 2×2×2 | 8 | 1.0 |
| L-triomino | 3 | 2 | 14 | {1,1,2} | 2×2×1 | 4 | 0.75 |
| Pair at x=0 and x=2 | 2 | 0 | 12 | {0,0} | 3×1×1 | 3 | 2/3 |

For the five-voxel line, four internal face pairs remove eight faces from the initial 30. Axis counts are X=2, Y=10, Z=10, totalling 22.

For the 2×2 square, the four perimeter-internal face pairs remove eight faces from 24, yielding 16. Axis counts are X=4, Y=4, Z=8.

For the solid cube, 12 shared pairs remove 24 faces from 48, yielding 24. Each axis has eight exposed faces. Every voxel has degree three.

For the L-triomino, two adjacencies remove four faces from 18, yielding 14. Its bounding box has volume four, so occupancy is 3/4.

Two voxels touching only at an edge or corner have E=0 and A=12. They are not face-connected. These contact cases are mathematically implied by the implementation's six-neighbour definition but are not explicit in `test_face_connectivity`.

A sparse pair at (0,0,0) and (9,9,9) has bounding dimensions 10×10×10, volume 1000 and occupancy 0.002. Existing tests cover a modest disconnected pair, not this large sparse case.

## 5. Test-coverage matrix

The supplied seven geometry modules contain 71 tests; `test_pentacube_orientations.py` contributes another ten, for 81 total.

| Module / actual tests | Main verified behaviour | Useful remaining gaps |
|---|---|---|
| `test_polycube_utils.py`: `test_normalization_and_translation_invariance`, `test_normalized_result_is_immutable_and_sorted`, `test_integer_valued_floats_are_accepted`, `test_invalid_shapes_raise_value_error`, `test_face_connectivity`, plus five canonical/orientation tests | Normalization, validation, connectivity basics, canonicalization | Generator input; edge-only and corner-only contact; explicit input permutations; invalid NaN/infinity; max-degree shape. |
| `test_surface_area.py`: ten tests including `test_single_voxel`, `test_straight_pentacube`, `test_l_triomino`, `test_disconnected_voxels`, `test_translation_invariance`, `test_rejects_empty_shape`, `test_rejects_duplicate_voxels` | Representative surface fixtures and invalid inputs | Randomized cross-checks; edge/corner contact explicit cases; large sparse fixture. |
| `test_face_adjacency_count.py`: ten tests including `test_surface_area_identity` | Adjacency fixtures, translation, A=6N−2E | Explicit edge/corner-only contact and higher-degree graph fixture. |
| `test_exposed_faces_by_axis.py`: eleven tests including `test_axis_counts_sum_to_surface_area`, `test_rotation_preserves_total_surface_area` | Axis totals, rotation and translation behaviour | Independent degree/adjacency cross-checks on generated shapes. |
| `test_bounding_box_dimensions.py`: ten tests including `test_rotation_permutates_dimensions` | Dimensions for common shapes and transforms | Very large sparse extents and large integer coordinates. |
| `test_shape_metrics.py`: ten tests including `test_rotation_invariance`, `test_disconnected_shape` | Bounding volume and occupancy | Extremely sparse occupancy and non-finite input explicitly. |
| `test_voxel_degrees.py`: ten tests including `test_degree_sum_equals_twice_adjacency_count` | Degree fixtures and handshake identity | Degree-six central voxel and generator input. |

Translation, basic invalid input, disconnected shape, isolated voxel and several cross-function identities are already covered. Missing cases are coverage opportunities, not demonstrated defects.

## 6. Performance

`is_face_connected()` is the main clear inefficiency. It uses `queue.pop(0)`, which shifts a Python list, and tests `ncoord in voxels`, which scans a list. In the worst case, these operations make traversal O(N²). A `set(normalized)` for membership and `collections.deque.popleft()` for the BFS queue would make traversal O(N) average time and O(N) memory. For very small pentacubes, practical benefit is negligible; for larger polycubes or repeated checks it is worthwhile.

`occupancy_ratio()` performs an avoidable second normalization via `bounding_box_volume(normalized)`. A small internal helper accepting already-normalized coordinates could remove the repeat sort and allocation. This is a minor improvement.

`bounding_box_dimensions()` also creates three temporary lists solely to take maxima; single-pass maxima would reduce temporary allocations, but this is unlikely to matter for the current workload. The set-based adjacency/degree/exposed-face loops are reasonable.

## 7. Findings and recommendations

### Confirmed defects

**None identified** in the reviewed source and tests.

### Test-coverage gaps

- **G1 — Edge/corner contact:** Medium. Add separate cases to `test_face_connectivity` showing that edge and corner contact do not connect.
- **G2 — Degree six:** Medium. Add a seven-voxel 3D cross; centre degree should be six and each leaf degree one.
- **G3 — Generator and order invariance:** Medium. Feed the same shape as list, tuple and generator, and permute voxel order; compare normalized geometry results.
- **G4 — Sparse bounding box:** Low. Add distant voxels and check volume/occupancy.
- **G5 — Non-finite floats:** Low. Explicitly test NaN and ±infinity for the validation contract.

### Optional improvements

- **P1 — BFS data structures:** Medium performance. Replace list membership with a set and FIFO list with deque in `is_face_connected()`.
- **P2 — Duplicate normalization:** Low performance. Avoid normalizing the already-normalized coordinates in `occupancy_ratio()`.
- **P3 — Minor cleanup:** Low. `List` is imported but unused; rotation helper imports are repeated locally and at module scope.

Recommended order: add G1 and G2 first, then G3; consider P1 if connectivity is used on larger pieces; defer P2/P3 unless the module is being touched anyway.

## 8. Confidence and limitations

Confidence is high for the reviewed mathematical identities and fixture results: the code was inspected, the 81 tests passed, and 500 deterministic generated shapes passed the invariants. Confidence is high that the BFS implementation has quadratic worst-case overhead, based on its list membership and `pop(0)` operations. Large-scale runtime impact was not benchmarked. No formal proof over all possible inputs was attempted. The rotation module was retained and its tests run, but this is not a full audit of rotation conventions beyond their interaction with normalization and geometry properties.
