# Spark / OpenCode Evaluation Notes

**Environment described in the experiments:** Windows 10 Pro on TW2; Ollama local server; OpenCode Desktop/CLI 2.1.2; custom OpenAI-compatible provider; Spark-X2.6-4B Q4_K_M with an 8K context alias; `reasoning_effort: none` in successful configurations.

## What worked

- Direct Ollama API calls to Spark 1.7B and 4B returned responses. The 1.7B direct test was reported at approximately 31.94 tokens/second.
- The Spark 4B OpenAI-compatible endpoint completed non-streaming and streaming probes. A clean OpenCode CLI smoke test returned the exact requested sentinel `OPENCODE_DIAGNOSTIC_7319`.
- Several bounded, single-function coding tasks were completed and independently tested: `face_adjacency_count()`, `bounding_box_dimensions()` and `voxel_degrees()`. The latter was followed by the successful 81-test regression.
- The verified snapshots were retained in separate project directories; the original 81-test baseline was not modified by the failed connected-components experiments or audit runs.

## What did not work reliably

- A connected-components implementation task repeatedly failed to create the requested function. At least one run returned an unrelated checkpoint summary; another pursued an unrelated `occupancy_ratio` investigation and TypeScript file search.
- Automatic compaction was observed to create checkpoint-oriented summaries that replaced the coding objective. Explicitly setting `compaction.auto: false` removed compaction events, but did not by itself stop task drift.
- With compaction disabled, the exported session recorded repeated synthetic continuation messages stating that output hit the token limit. The actual tool sequence included unrelated glob/search/shell activity in one run.
- A read-only audit using deny-all permissions with per-file read exceptions denied several intended reads. A subsequent broader read-only setup allowed reading but did not keep Spark focused on the requested geometry audit; it shifted toward rotation/orientation material.
- OpenCode exit code 0 was not a reliable indicator of a successful edit. File presence and SHA-256 verification were necessary. Failed runs often left source files unchanged.

## Practical conclusion

Spark-X2.6-4B looks useful for bounded, well-specified tasks, especially a single-function change with an independent test suite prepared in advance. It is not yet reliable enough in this OpenCode/Ollama configuration for long autonomous, multi-step coding or audit jobs without supervision.

Recommended operating discipline:

1. Use a fresh isolated working directory for each task.
2. Keep task scope narrow and specify exactly which file may change.
3. Prepare independent tests before invoking the model.
4. Use explicit `compaction.auto: false` where task continuity matters, and give a sufficient output limit.
5. Capture stdout/stderr and export the session when behaviour is unexpected.
6. Treat CLI exit status as informational only; verify the requested code change and run tests independently.
7. Check SHA-256 hashes of protected files before and after the task.
8. Stop after one or two repeated failures and diagnose tool/session behaviour rather than looping prompts.

## Interpretation limits

These observations characterise the specific model, quantisation, Ollama alias, OpenCode 2.1.2 build and configuration tested. They do not establish that Spark is generally incapable of longer coding tasks, nor that the observed failures will occur with other provider integrations or model variants.
